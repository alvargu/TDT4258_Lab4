#ifndef EVENTSYSTEM_H_
#define EVENTSYSTEM_H_

#include <avr/io.h>
#include <stdbool.h>

void eventSystem_init(void);


#endif