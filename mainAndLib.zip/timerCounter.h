#ifndef TIMERCOUNTER_H
#define TIMERCOUNTER_H

#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdint.h>

void TCA0_init(void);

#endif  // TIMERCOUNTER_H
